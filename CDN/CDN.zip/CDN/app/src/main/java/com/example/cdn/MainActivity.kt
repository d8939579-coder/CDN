@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.cdn

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.cdn.ui.theme.CDNTheme
import com.example.cdn.ui.theme.Red
import com.example.cdn.ui.theme.Black
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val context = LocalContext.current
            val dataStoreManager = remember { DataStoreManager(context) }
            val isDarkTheme by dataStoreManager.isDarkTheme.collectAsState(initial = true)
            val isLoggedIn by dataStoreManager.isLoggedIn.collectAsState(initial = false)
            
            CDNTheme(darkTheme = isDarkTheme) {
                MainNavigation(dataStoreManager, isLoggedIn)
            }
        }
    }
}

@Composable
fun MainNavigation(dataStoreManager: DataStoreManager, startLoggedIn: Boolean) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = if (startLoggedIn) "main" else "splash") {
        composable("splash") { SplashScreen(navController) }
        composable("login") { LoginScreen(navController, dataStoreManager) }
        composable("register") { RegisterScreen(navController, dataStoreManager) }
        composable("main") { MainScreen(navController, dataStoreManager) }
        composable("dm") { DMScreen(navController) }
    }
}

@Composable
fun SplashScreen(navController: NavHostController) {
    var startAnimation by remember { mutableStateOf(false) }
    val alpha by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(1500),
        label = "alpha"
    )

    LaunchedEffect(Unit) {
        startAnimation = true
        delay(2500)
        navController.navigate("login") {
            popUpTo("splash") { inclusive = true }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.alpha(alpha)
        ) {
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(Red)
                    .border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("CDN", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
            }
            
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                "CLAN DEI NUDI",
                color = Red,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                "PUNIRE I DIAVOLI RITENUTI INNOCENTI",
                color = Red.copy(alpha = 0.7f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontStyle = FontStyle.Italic,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun PermissionHandler(onPermissionsGranted: () -> Unit) {
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results -> 
        if (results.all { it.value }) {
            onPermissionsGranted()
        }
    }

    LaunchedEffect(Unit) {
        val permissions = mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        launcher.launch(permissions.toTypedArray())
    }
}

@Composable
fun LoginScreen(navController: NavHostController, dataStoreManager: DataStoreManager) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showError by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    val onLoginClick: () -> Unit = {
        if (email.isNotBlank() && password.isNotBlank()) {
            scope.launch {
                dataStoreManager.saveLoginState(true, email.split("@")[0], email)
                navController.navigate("main") { popUpTo("login") { inclusive = true } }
            }
        } else {
            showError = true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Black)
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("CLAN DEI NUDI", color = Red, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(modifier = Modifier.height(48.dp))
        
        OutlinedTextField(
            value = email,
            onValueChange = { email = it; showError = false },
            label = { Text("Email", color = Red) },
            modifier = Modifier.fillMaxWidth(),
            isError = showError && email.isBlank(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Red, unfocusedBorderColor = Red.copy(alpha = 0.5f),
                focusedTextColor = Color.White, unfocusedTextColor = Color.White
            )
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it; showError = false },
            label = { Text("Password", color = Red) },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            isError = showError && password.isBlank(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { 
                keyboardController?.hide()
                onLoginClick() 
            }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Red, unfocusedBorderColor = Red.copy(alpha = 0.5f),
                focusedTextColor = Color.White, unfocusedTextColor = Color.White
            )
        )
        
        if (showError) {
            Text("Campi obbligatori", color = Red, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        }

        Spacer(modifier = Modifier.height(32.dp))
        Button(
            onClick = { onLoginClick() },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Red),
            shape = RoundedCornerShape(4.dp)
        ) {
            Text("ACCEDI", color = Black, fontWeight = FontWeight.Bold)
        }
        TextButton(onClick = { navController.navigate("register") }) {
            Text("Registrati", color = Red)
        }
    }
}

@Composable
fun RegisterScreen(navController: NavHostController, dataStoreManager: DataStoreManager) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showError by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    val onRegisterClick: () -> Unit = {
        if (name.isNotBlank() && email.isNotBlank() && password.isNotBlank()) {
            scope.launch {
                dataStoreManager.saveLoginState(true, name, email)
                navController.navigate("main") { popUpTo("register") { inclusive = true } }
            }
        } else {
            showError = true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Black)
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("REGISTRATI", color = Red, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(48.dp))
        
        OutlinedTextField(
            value = name,
            onValueChange = { name = it; showError = false },
            label = { Text("Username", color = Red) },
            modifier = Modifier.fillMaxWidth(),
            isError = showError && name.isBlank(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Red, unfocusedBorderColor = Red.copy(alpha = 0.5f), focusedTextColor = Color.White, unfocusedTextColor = Color.White)
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = email,
            onValueChange = { email = it; showError = false },
            label = { Text("Email", color = Red) },
            modifier = Modifier.fillMaxWidth(),
            isError = showError && email.isBlank(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Red, unfocusedBorderColor = Red.copy(alpha = 0.5f), focusedTextColor = Color.White, unfocusedTextColor = Color.White)
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it; showError = false },
            label = { Text("Password", color = Red) },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            isError = showError && password.isBlank(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { 
                keyboardController?.hide()
                onRegisterClick() 
            }),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Red, unfocusedBorderColor = Red.copy(alpha = 0.5f), focusedTextColor = Color.White, unfocusedTextColor = Color.White)
        )
        
        if (showError) {
            Text("Tutti i campi obbligatori", color = Red, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        }

        Spacer(modifier = Modifier.height(32.dp))
        Button(
            onClick = { onRegisterClick() },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Red),
            shape = RoundedCornerShape(4.dp)
        ) {
            Text("REGISTRATI", color = Black, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun MainScreen(navController: NavHostController, dataStoreManager: DataStoreManager) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var permissionsGranted by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    if (!permissionsGranted) {
        PermissionHandler { permissionsGranted = true }
    }
    
    if (showSettings) {
        SettingsDialog(
            dataStoreManager = dataStoreManager,
            onDismiss = { showSettings = false }
        )
    }

    Scaffold(
        topBar = {
            if (selectedTab == 0) {
                CenterAlignedTopAppBar(
                    title = { Text("CLAN DEI NUDI", color = Red, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp) },
                    actions = {
                        IconButton(onClick = { navController.navigate("dm") }) {
                            Icon(Icons.Default.Email, contentDescription = "DMs", tint = Red)
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            }
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.background, tonalElevation = 8.dp) {
                val items = listOf(
                    Triple(0, Icons.Default.Home, "Home"),
                    Triple(1, Icons.Default.Search, "Scopri"),
                    Triple(2, Icons.AutoMirrored.Filled.List, "Voti"),
                    Triple(3, Icons.Default.Person, "Profilo")
                )
                items.forEach { (index, icon, label) ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(icon, contentDescription = label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Red, unselectedIconColor = Color.Gray,
                            indicatorColor = Color.Transparent
                        )
                    )
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (selectedTab) {
                0 -> FeedContent()
                1 -> DiscoverContent()
                2 -> PollsContent()
                3 -> ProfileContent(dataStoreManager, onSettingsClick = { showSettings = true }, onLogout = {
                    (navController.context as? ComponentActivity)?.let { _ ->
                        // Logout logic
                    }
                })
            }
        }
    }
}

@Composable
fun DMScreen(navController: NavHostController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Direct", color = Red, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Red)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding)) {
            items(10) { i ->
                ListItem(
                    headlineContent = { Text("Membro #$i", color = MaterialTheme.colorScheme.onBackground) },
                    supportingContent = { Text("Messaggio criptato...", color = Color.Gray) },
                    leadingContent = {
                        Box(modifier = Modifier.size(50.dp).clip(CircleShape).background(Color.DarkGray).border(1.dp, Red, CircleShape))
                    },
                    modifier = Modifier.clickable { },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                )
                HorizontalDivider(color = Color.Gray.copy(alpha = 0.1f))
            }
        }
    }
}

@Composable
fun FeedContent() {
    Column(modifier = Modifier.fillMaxSize()) {
        LazyRow(
            modifier = Modifier.padding(vertical = 10.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(modifier = Modifier.size(64.dp).clip(CircleShape).background(Color.DarkGray).border(2.dp, Red, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Red)
                    }
                    Text("La tua", color = MaterialTheme.colorScheme.onBackground, fontSize = 11.sp)
                }
            }
            items(8) { i ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(modifier = Modifier.size(64.dp).clip(CircleShape).background(Color.DarkGray).border(2.dp, Red, CircleShape))
                    Text("Utente $i", color = MaterialTheme.colorScheme.onBackground, fontSize = 11.sp)
                }
            }
        }
        HorizontalDivider(color = Color.Gray.copy(alpha = 0.2f))
        LazyColumn {
            items(5) { i -> PostItem(i) }
        }
    }
}

@Composable
fun PostItem(index: Int) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(32.dp).clip(CircleShape).background(Red))
            Spacer(modifier = Modifier.width(10.dp))
            Text("Esecutore_$index", color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.weight(1f))
            Icon(Icons.Default.MoreVert, contentDescription = null, tint = Color.Gray)
        }
        Box(modifier = Modifier.fillMaxWidth().height(350.dp).background(Color(0xFF0A0A0A))) {
            Icon(Icons.Default.Lock, contentDescription = null, tint = Red.copy(alpha = 0.1f), modifier = Modifier.size(60.dp).align(Alignment.Center))
        }
        Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.FavoriteBorder, contentDescription = null, tint = Red, modifier = Modifier.size(28.dp).padding(4.dp))
            Icon(Icons.Default.Email, contentDescription = null, tint = Red, modifier = Modifier.size(28.dp).padding(4.dp))
            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = Red, modifier = Modifier.size(28.dp).padding(4.dp))
            Spacer(modifier = Modifier.weight(1f))
            Icon(Icons.Default.Info, contentDescription = null, tint = Red, modifier = Modifier.size(28.dp).padding(4.dp))
        }
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
            Text("Piace a 42 persone", color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("Giustizia per tutti. #CDN", color = MaterialTheme.colorScheme.onBackground, fontSize = 13.sp)
            Text("2 ore fa", color = Color.Gray, fontSize = 10.sp)
        }
        Spacer(modifier = Modifier.height(10.dp))
    }
}

@Composable
fun ProfileContent(dataStoreManager: DataStoreManager, onSettingsClick: () -> Unit, onLogout: () -> Unit) {
    val userName by dataStoreManager.userName.collectAsState(initial = "Esecutore")
    Column(modifier = Modifier.fillMaxSize()) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(80.dp).clip(CircleShape).background(Color.DarkGray).border(1.dp, Red, CircleShape)) {
                Icon(Icons.Default.Person, contentDescription = null, tint = Red, modifier = Modifier.size(40.dp).align(Alignment.Center))
            }
            Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceEvenly) {
                ProfileStat("42", "Post")
                ProfileStat("1.2k", "Follower")
                ProfileStat("350", "Seguiti")
            }
        }
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Text(userName, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text("Profilo ufficiale del Clan", color = Color.Gray, fontSize = 13.sp)
        }
        Row(modifier = Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onSettingsClick() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, Color.Gray), shape = RoundedCornerShape(8.dp)) {
                Text("Modifica", color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp)
            }
            Button(onClick = { onLogout() }, modifier = Modifier.weight(0.5f), colors = ButtonDefaults.buttonColors(containerColor = Red), shape = RoundedCornerShape(8.dp)) {
                Text("Esci", color = Black, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            items(5) { i ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(modifier = Modifier.size(56.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface).border(1.dp, Color.Gray, CircleShape))
                    Text("Voto $i", fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground)
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        TabRow(selectedTabIndex = 0, containerColor = Color.Transparent, contentColor = Red, indicator = { tabPositions ->
            SecondaryIndicator(Modifier.tabIndicatorOffset(tabPositions[0]), color = Red)
        }) {
            Tab(selected = true, onClick = {}, icon = { Icon(Icons.Default.Menu, contentDescription = null) })
            Tab(selected = false, onClick = {}, icon = { Icon(Icons.Default.AccountBox, contentDescription = null) })
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(1.dp),
            horizontalArrangement = Arrangement.spacedBy(1.dp),
            verticalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            items(12) { i ->
                Box(modifier = Modifier.aspectRatio(1f).background(if (i % 2 == 0) Color.DarkGray else Color(0xFF1A1A1A)))
            }
        }
    }
}

@Composable
fun ProfileStat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(label, color = MaterialTheme.colorScheme.onBackground, fontSize = 12.sp)
    }
}

@Composable
fun SettingsDialog(dataStoreManager: DataStoreManager, onDismiss: () -> Unit) {
    val isDarkTheme by dataStoreManager.isDarkTheme.collectAsState(initial = true)
    val selectedArea by dataStoreManager.selectedArea.collectAsState(initial = "Rilevamento...")
    val scope = rememberCoroutineScope()
    Dialog(onDismissRequest = onDismiss) {
        Card(modifier = Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, Red)) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text("PROTOCOLLO CDN", color = Red, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(modifier = Modifier.height(20.dp))
                Text("AREA: $selectedArea", color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.clickable { 
                    scope.launch { dataStoreManager.saveArea(if (selectedArea.contains("Italia")) "Asia / Seoul" else "Europa / Italia") }
                })
                Spacer(modifier = Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("TEMA SCURO", color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                    Switch(checked = isDarkTheme, onCheckedChange = { scope.launch { dataStoreManager.saveTheme(it) } }, colors = SwitchDefaults.colors(checkedThumbColor = Red))
                }
                Spacer(modifier = Modifier.height(24.dp))
                Button(onClick = { onDismiss() }, modifier = Modifier.align(Alignment.End), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                    Text("CHIUDI", color = Black)
                }
            }
        }
    }
}

@Composable
fun PollsContent() {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("VOTAZIONI", color = Red, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(modifier = Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(3) { i ->
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0A0A)), border = BorderStroke(1.dp, Red), shape = RoundedCornerShape(8.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("TARGET #0$i", color = Red, fontWeight = FontWeight.Bold)
                        Text("Votazione attiva per la sentenza finale.", color = Color.White, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = {}, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                            Text("VOTA ORA", color = Black)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DiscoverContent() {
    Column(modifier = Modifier.fillMaxSize()) {
        SearchBar(
            query = "", onQueryChange = {}, onSearch = {}, active = false, onActiveChange = {},
            placeholder = { Text("Cerca nel Clan...") },
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            colors = SearchBarDefaults.colors(containerColor = Color.DarkGray.copy(alpha = 0.3f))
        ) {}
        LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(1.dp), horizontalArrangement = Arrangement.spacedBy(1.dp), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            items(18) { _ -> Box(modifier = Modifier.aspectRatio(1f).background(Color(0xFF0F0F0F))) }
        }
    }
}
